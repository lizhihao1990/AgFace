CampbellLogger
==============

R-package to import, merge, and visualise Campbell Scientific *.dat files

See 

	help(package = CampbellLogger) 

for details on the functions provided by this package.
