GlasshouseClimateImport
=======================

R-package to import, and merge Creswick glasshouse *.dat files

See 

	help(package = GlasshouseClimateImport) 

for details on the functions provided by this package.
